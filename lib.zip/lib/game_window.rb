class GameWindow < Hasu::Window
  SPRITE_SIZE = 128
  SPRITE_SIZE2 = 700
  WINDOW_X = 1280
  WINDOW_Y = 720

  def initialize
    super(WINDOW_X, WINDOW_Y, false)
    @background_sprite = Gosu::Image.new(self, 'images/background.png', true)
    @koala_sprite = Gosu::Image.new(self, 'images/goku2.png', true)
    @enemy_sprite = Gosu::Image.new(self, 'images/Freezer.png', true)
    @enemy2_sprite = Gosu::Image.new(self, 'images/buu.png', true)
    @enemy3_sprite = Gosu::Image.new(self, 'images/cell.png', true)
    @enemy4_sprite = Gosu::Image.new(self, 'images/beerus.png', true)
    @tab_enemy = [@enemy_sprite, @enemy2_sprite, @enemy3_sprite, @enemy4_sprite]
    @flag_sprite = Gosu::Image.new(self, 'images/DB.png', true)
    @font = Gosu::Font.new(self, Gosu::default_font_name, 30)
    @flag = {x: WINDOW_X - SPRITE_SIZE, y: WINDOW_Y - SPRITE_SIZE2}
    @music = Gosu::Song.new(self, "musics/Chala-head-Chala.wav")
    reset
  end

  def update
    @player[:x] += @speed if button_down?(Gosu::Button::KbRight)
    @player[:x] -= @speed if button_down?(Gosu::Button::KbLeft)
    @player[:y] += @speed if button_down?(Gosu::Button::KbDown)
    @player[:y] -= @speed if button_down?(Gosu::Button::KbUp)
    @player[:x] = normalize(@player[:x], WINDOW_X - SPRITE_SIZE)
    @player[:y] = normalize(@player[:y], WINDOW_Y - SPRITE_SIZE)
    handle_enemies
    handle_quit
    if winning?
      reinit
      random_items
    end
    if loosing?
      reset
    end
  end



  def draw
    @font.draw("Level #{@enemies.length}", WINDOW_X - WINDOW_X + 10, 10, 3, 1.0, 1.0, Gosu::Color::WHITE)

    @koala_sprite.draw(@player[:x], @player[:y], 2)
    @enemies.each do |enemy|
      @tab_enemy[3].draw(enemy[:x], enemy[:y], 2) || @tab_enemy[0].draw(enemy[:x], enemy[:y], 2) || @enemy3_sprite.draw(enemy[:x], enemy[:y], 2) #!= @enemy4_sprite.draw(enemy[:x], enemy[:y], 2)
      #@enemy2_sprite.draw(enemy[:x], enemy[:y], 2)
    end
    @flag_sprite.draw(@flag[:x], @flag[:y], 1)
    (0..8).each do |x|
      (0..8).each do |y|
        @background_sprite.draw(x * SPRITE_SIZE, y * SPRITE_SIZE, 0)
      end
    end
  end

  private

  #def add_random
  #  @add_enemy = @tab_enemy.sample
  #end

  def random_items()
    @add_enemy = @tab_enemy.sample(1 + rand(@tab_enemy.count))
  end

#  class Array
#    def random_element
#      @add_enemy = self[rand(@tab_enemy)]
#    end
#    @add_enemy
#  end

  def reset
    @high_score = 0
    @enemies = []
    @speed = 3
    if @music
      @music.stop
      @music.play
    end
    reinit
  end

  def reinit
    @speed += 1
    @player = {x: 000, y: 700}
    #@enemies = @add_enemy
    @enemies.push({ x: WINDOW_X + rand(100), y: WINDOW_Y + rand(100)})
    high_score
  end

  def high_score
    unless File.exist?('hiscore')
      File.new('hiscore', 'w')
    end
    @new_high_score = [@enemies.count, File.read('hiscore').to_i].max
    File.write('hiscore', @new_high_score)
  end

  def collision?(a, b)
    (a[:x] - b[:x]).abs < SPRITE_SIZE / 2 &&
    (a[:y] - b[:y]).abs < SPRITE_SIZE / 2
  end

  def loosing?
    @enemies.any? do |enemy|
      collision?(@player, enemy)
    end
  end

  def winning?
    collision?(@player, @flag)
  end



  def random_mouvement
    (rand(3) - 1)
  end

  def normalize(v, max)
    if v < 0
      0
    elsif v > max
      max
    else
      v
    end
  end

  def handle_quit
    if button_down? Gosu::KbEscape
      close
    end
  end

  def handle_enemies
    @enemies = @enemies.map do |enemy|
      enemy[:timer] ||= 0
      if enemy[:timer] == 0
        enemy[:result_x] = random_mouvement
        enemy[:result_y] = random_mouvement
        enemy[:timer] = 50 + rand(50)
      end
      enemy[:timer] -= 1

      new_enemy = enemy.dup
      new_enemy[:x] += new_enemy[:result_x] * @speed
      new_enemy[:y] += new_enemy[:result_y] * @speed
      new_enemy[:x] = normalize(new_enemy[:x], WINDOW_X - SPRITE_SIZE)
      new_enemy[:y] = normalize(new_enemy[:y], WINDOW_Y - SPRITE_SIZE)
      unless collision?(new_enemy, @flag)
        enemy = new_enemy
      end
      enemy
    end
  end
end
